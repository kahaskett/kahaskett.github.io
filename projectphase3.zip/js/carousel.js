document.addEventListener('DOMContentLoaded', function() {
    let currentIndex = 0; // Index of the current image
    const carousel = document.querySelector('.carousel'); // Select the carousel div
    const images = carousel.querySelectorAll('img'); // Select all images inside the carousel
    const totalImages = images.length; // Get the total number of images

    // Function to show the current image
    function showImage(index) {
        const offset = -index * 100; // Move the carousel by 100% of the width of the image
        carousel.style.transform = `translateX(${offset}%)`; // Apply the offset to move the images
    }

    // Initialize the carousel to show the first image
    showImage(currentIndex);

    // Handle previous and next buttons
    const prevButton = document.querySelector('.carousel-container .prev'); // Previous button
    const nextButton = document.querySelector('.carousel-container .next'); // Next button

    // Event listener for the previous button
    prevButton.addEventListener('click', function() {
        currentIndex = (currentIndex - 1 + totalImages) % totalImages; // Decrease index and wrap around
        showImage(currentIndex);
    });

    // Event listener for the next button
    nextButton.addEventListener('click', function() {
        currentIndex = (currentIndex + 1) % totalImages; // Increase index and wrap around
        showImage(currentIndex);
    });

    // Automatic transition every 3 seconds
    setInterval(function() {
        currentIndex = (currentIndex + 1) % totalImages; // Increment index and wrap around
        showImage(currentIndex);
    }, 3000); // Change image every 3 seconds
});
