// Select elements from the DOM
const quoteText = document.getElementById('quote-text');
const fetchQuoteButton = document.getElementById('fetch-quote');

// Function to fetch a random Jennifer Hudson quote
async function fetchQuote() {
    try {
        // Fetch a random quote from the Quotable API
        const response = await fetch('https://api.quotable.io');

        // Check if the response is OK
        if (!response.ok) {
            throw new Error('Failed to fetch quote');
        }

        // Parse the JSON response
        const data = await response.json();

        // Update the dynamic quote text
        quoteText.textContent = `"${data.content}"`;
    } catch (error) {
        // Display an error message if the fetch fails
        quoteText.textContent = 'Sorry, we could not fetch a quote. Please try again!';
        console.error('Error fetching quote:', error);
    }
}

// Add event listener to the button
fetchQuoteButton.addEventListener('click', fetchQuote);
