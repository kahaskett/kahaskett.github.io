document.addEventListener("DOMContentLoaded", function() {
    const accordions = document.querySelectorAll('.accordion');

    accordions.forEach(accordion => {
        accordion.addEventListener('click', function() {
            // Toggle the active class on the clicked accordion button
            this.classList.toggle('active');

            // Get the corresponding accordion content
            const content = this.nextElementSibling;

            // If content is visible, hide it; otherwise, show it
            if (content.style.maxHeight) {
                content.style.maxHeight = null;
            } else {
                content.style.maxHeight = content.scrollHeight + "px";
            }
        });
    });
});
